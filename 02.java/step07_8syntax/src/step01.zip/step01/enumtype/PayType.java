package step01.enumtype;

public enum PayType {
	CARD,
	CASH(),
	ETC
}
