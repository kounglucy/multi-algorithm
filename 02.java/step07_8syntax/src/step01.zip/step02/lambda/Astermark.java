package step02.lambda;

public interface Astermark {
	public void addAstermark(String str1, String str2);
}
